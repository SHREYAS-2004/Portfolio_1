import React from "react";
import CashBalance from "./components/CashBalance";
import BuyAsset from "./components/BuyAsset";
import SellAsset from "./components/SellAsset";
import Dashboard from "./components/Dashboard";

function App() {
  return (
    <div style={{ padding: "20px" }}>
      <h1>Portfolio Manager</h1>

      <CashBalance />
      <hr />

      <BuyAsset />
      <SellAsset />
      <hr />

      <Dashboard />
    </div>
  );
}

export default App;
