import React, { useEffect, useState } from "react";
import { getDashboard } from "../api/portfolioApi";

function Dashboard() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    const res = await getDashboard();
    setData(res.data);
  };

  if (!data) return <p>Loading...</p>;

  return (
    <div>
      <h2>Portfolio Dashboard</h2>

      <p>Cash Balance: ₹ {data.cashBalance}</p>
      <p>Total Asset Value: ₹ {data.totalAssetValue}</p>
      <p>Total Portfolio Value: ₹ {data.totalPortfolioValue}</p>

      <h3>Assets</h3>
      <table border="1">
        <thead>
          <tr>
            <th>Symbol</th>
            <th>Type</th>
            <th>Qty</th>
            <th>Avg Buy</th>
            <th>Current</th>
            <th>P/L</th>
          </tr>
        </thead>
        <tbody>
          {data.assets.map((a, i) => (
            <tr key={i}>
              <td>{a.symbol}</td>
              <td>{a.assetType}</td>
              <td>{a.quantity}</td>
              <td>{a.avgBuyPrice}</td>
              <td>{a.currentPrice}</td>
              <td>{a.profitOrLoss}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Dashboard;
