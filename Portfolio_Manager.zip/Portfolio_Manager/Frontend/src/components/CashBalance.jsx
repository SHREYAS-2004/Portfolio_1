import React, { useEffect, useState } from "react";
import { getCashBalance, updateCashBalance } from "../api/portfolioApi";

function CashBalance() {
  const [cash, setCash] = useState(0);
  const [amount, setAmount] = useState("");

  useEffect(() => {
    fetchCash();
  }, []);

  const fetchCash = async () => {
    const res = await getCashBalance();
    setCash(res.data.cashBalance);
  };

  const addCash = async () => {
    await updateCashBalance(Number(amount));
    setAmount("");
    fetchCash();
  };

  return (
    <div>
      <h2>Cash Balance</h2>
      <p>₹ {cash}</p>

      <input
        type="number"
        placeholder="Add amount"
        value={amount}
        onChange={(e) => setAmount(e.target.value)}
      />
      <button onClick={addCash}>Add Cash</button>
    </div>
  );
}

export default CashBalance;
