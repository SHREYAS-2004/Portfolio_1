package com.example.portfolio.beans;

public enum AssetType {
    STOCK,
    CRYPTO
}
